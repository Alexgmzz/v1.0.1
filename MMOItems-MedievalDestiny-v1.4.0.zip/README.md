# Arsenal de los Seis Caminos — Medieval Destiny

Paquete de contenido MMOItems para Paper 1.21.11. Amplía los YAML existentes; no reemplaza las tablas de objetos ni las runas actuales.

## Modelos y texturas v1.4.0

Instala el resource pack v1.4.0 junto con estos YAML. No uses el pack con los archivos MMOItems anteriores: los objetos de esta expansión ya no dependen de selectores globales de `custom_model_data`.

- Las 24 armas, 24 piezas de armadura y 120 runas reciben un `model` namespaced (`medievaldestiny:...`) para que el pack del cliente no sustituya su apariencia por la vanilla.
- Las 24 piezas de armadura tienen además `equippable-slot` y `equippable-model`; seis capas UV de armadura coordinadas aplican la apariencia del conjunto al llevarlo puesto.
- El inventario usa los modelos 3D del pack. Al vestir la armadura, Minecraft mantiene la geometría bípeda estándar y aplica la textura personalizada del conjunto; la geometría de armadura equipable no admite mallas arbitrarias desde un resource pack vanilla.
- Los seis modelos de equipo se llaman `medievaldestiny:armor/bastion`, `medievaldestiny:armor/oath`, `medievaldestiny:armor/watcher`, `medievaldestiny:armor/dance`, `medievaldestiny:armor/law` y `medievaldestiny:armor/dawn`. Los IDs de item y las referencias de textura deben permanecer emparejados con el pack v1.4.0.
- MMOItems debe ser una versión 6.10.x que incluya los stats `model`, `equippable-slot` y `equippable-model`, disponibles desde Minecraft 1.21.2. No requiere instalar un mod en el cliente.

## Contenido

- 24 armas: 4 por arquetipo. Hay roles diferenciados de vanguardia, control, distancia, crítico, apoyo y magia.
- 24 piezas de armadura: seis conjuntos completos, uno por arquetipo.
- 6 bonificaciones de conjunto, en umbrales de 2 y 4 piezas.
- 6 reliquias épicas con habilidades activas/por impacto y enfriamientos explícitos.
- 1 báculo mítico personal para nigromancia: `MD_NIGROMANTE_VESPERA_ULTIMO_OFICIO`.
- 48 recetas de equipo en la Forja Arcana (más 5 recetas utilitarias preexistentes): progresión rara con recursos de grindeo y reliquias que exigen Núcleo Rúnico más Núcleo de Dragón o Esencia Sagrada.
- Todo el equipo mantiene socket `Uncolored` cuando el tipo lo admite: acepta gemas sin color y runas compatibles de MMOItems.

## Catálogo de la expansión

| Arquetipo | Armas de progresión (RARE) | Reliquia (EPIC) |
|---|---|---|
| Guerrero | `MD_GUERRERO_HACHA_QUEBRANTADORA`, `MD_GUERRERO_MARTILLO_DE_BRECHA` | `MD_RELIQUIA_GUERRERO_CORAZON_DEL_BASTION` — Earthquake, daño de área moderado, 22 s |
| Caballero | `MD_CABALLERO_ESCUDO_DEL_VOTO`, `MD_CABALLERO_LANZA_DEL_ESTANDARTE` | `MD_RELIQUIA_CABALLERO_LANZA_DEL_REINO` — Thrust, 20 s |
| Explorador | `MD_EXPLORADOR_BALISTA_DEL_VIGIA`, `MD_EXPLORADOR_LANZA_DE_CAZA` | `MD_RELIQUIA_EXPLORADOR_OJO_DEL_DRAGON` — marca al objetivo, 16 s |
| Pícaro | `MD_PICARO_KATANA_DE_BRUMA`, `MD_PICARO_ESTILETE_DE_PENUMBRA` | `MD_RELIQUIA_PICARO_ULTIMO_SUSURRO` — Backstab, 16 s |
| Arcanista | `MD_ARCANISTA_VARITA_DE_CENIZA`, `MD_ARCANISTA_GRIMORIO_DE_ECOS` | `MD_RELIQUIA_ARCANISTA_CORAZON_DE_CENIZA` — Firebolt, 18 s |
| Clérigo | `MD_CLERIGO_ESCUDO_DE_LA_AURORA`, `MD_CLERIGO_MARTILLO_DEL_PEREGRINO` | `MD_RELIQUIA_CLERIGO_CAMPANA_DEL_ALBA` — Heal de 4 puntos, 25 s |
| Nigromante | `MD_NIGROMANTE_VESPERA_ULTIMO_OFICIO` — Báculo del Último Oficio, objeto mítico de entrega administrativa |

Los nombres de clase describen el rol recomendado; no imponen bloqueo de clase porque las clases de Medieval Destiny no están conectadas a MMOCore. La Lanza del Estandarte es de dos manos y no se combina con escudo.

## Decisiones de compatibilidad

Las clases de combate las maneja MedievalDestinyRPG; no está instalado MMOCore. Por eso el nombre y la función de cada equipo recomiendan un arquetipo, pero no se inventa una restricción `required-class` que el servidor no pueda verificar. Tampoco se usan requisitos de nivel de MMOCore. El servidor puede imponer bloqueos por clase en una integración posterior del plugin propio.

La expansión introduce dos escalones: armas RARE con atributos laterales y coste de acero/recursos mágicos, y reliquias EPIC con un efecto distintivo y coste de jefe. Se usan habilidades existentes en la instalación de MMOItems/MythicLib, no habilidades inventadas. Los poderes se mantienen contenidos (daño o curación bajos y 16–25 s de enfriamiento); falta medirlos en el servidor real antes de abrirlos al público.

## IDs y entrega de objetos

Usa `/mi give <jugador> <tipo> <ID>` (se puede añadir cantidad al final). Ejemplos:

```text
/mi give LexxG_7 SWORD MD_GUERRERO_FILO_DEL_BASTION
/mi give LexxG_7 ARMOR MD_ARCANISTA_LEY_TUNICA
/mi give LexxG_7 BOW MD_EXPLORADOR_ARCO_DEL_VIGIA
/mi give LexxG_7 STAFF MD_NIGROMANTE_VESPERA_ULTIMO_OFICIO
```

El Báculo del Último Oficio no tiene receta: está deshabilitado para crafteo, fundición y reparación. Su modelo tridimensional y atlas de textura están incluidos en el pack v1.4.0. El ID de item usa `medievaldestiny:vespera_staff`; se conserva `CustomModelData: 1201` como dato histórico, pero la apariencia se resuelve mediante el componente `model` namespaced. La apariencia final debe confirmarse dentro del cliente de Minecraft.

Las recetas aparecen en la estación `arcane-forge`; su comando configurado es `/arcaneforge` y requiere `mmoitems.arcane_forge`. También puede abrirse para un jugador desde la consola con:

```text
/mi stations open arcane-forge LexxG_7
```

Las runas compatibles se aplican arrastrándolas al objeto con socket libre, según la mecánica Gem Stones de MMOItems. Los sockets son un sistema separado de las ranuras del futuro Herrero Rúnico: aquí se aprovecha la integración real de runas que ya están registradas como `GEM_STONE`.

## Aplicación y validación

Archivos instalados bajo `plugins/MMOItems`: definiciones en los tipos nativos de `item/`, `item-sets.yml` y recetas añadidas a `crafting-stations/arcane-forge.yml`. Se conservaron copias previas en `_original-backup/` y una copia inmediata previa a la expansión en `_backup-expansion-20261016/`.

SnakeYAML 2.2 aceptó las 15 definiciones tocadas y la estación completa sin claves YAML duplicadas. Se comprobó que los tipos usados existen en `item-types.yml` y que cada receta apunta a uno de los 18 IDs nuevos. MMOItems aún debe cargarse dentro del servidor para confirmar el parseo de atributos/habilidades y la interacción real.

Al iniciar el servidor, ejecutar `/mi reload` y revisar la consola. Debe cargar sin errores los objetos, sets y recetas. Luego probar en este orden:

1. Ejecutar `/mi reload`; comprobar en consola que no haya errores al cargar tipos, atributos, habilidades, objetos o recetas.
2. Abrir la Forja Arcana; revisar los 48 resultados, ingredientes y vista previa; fabricar una rara y una reliquia de prueba.
3. Probar habilidades en un área segura: cada una debe activar una sola vez, respetar su enfriamiento y no duplicarse con clics rápidos.
4. Equipar sets de dos y cuatro piezas; confirmar que los bonos no se acumulan de forma inesperada y se retiran al quitar piezas.
5. Comparar daño/mitigación en PvE y PvP contra equipo de acero. Revisar especialmente balista, daño en área del Guerrero y curación del Clérigo antes de habilitar las recetas públicamente.
